<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">
</head>
<body>


<div class="container">
    <div class="mt-3 d-flex justify-content-end">
        <!-- Modal Trigger Button -->
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
        Open Form
        </button>
    </div>
    <div>
    <table class="table table-striped table-hover" id="tablee">
        <thead>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Gender</th>
            <th>Qualification</th>
            <th>Religion</th>
            <th>Image</th>
            <th>Action</th>
        </thead>
        <tbody id="tbody">

        </tbody>
    </table>
    </div>
</div>

<!-- Modal Structure -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">User Information Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- Form Starts -->
        <form  id="userForm" method="POST" enctype="multipart/form-data">
          
          <!-- Name Input -->
          <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" required>
            <input type="hidden" name="id" id="id">
          </div>

          <!-- Phone Input -->
          <div class="form-group">
            <label for="phone">Phone:</label>
            <input type="tel" class="form-control" id="phone" name="phone" required>
          </div>

          <!-- Email Input -->
          <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" required>
          </div>

          <!-- Gender Radio Buttons -->
          <div class="form-group">
            <label>Gender:</label><br>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="gender" id="genderMale" value="Male" required>
              <label class="form-check-label" for="genderMale">Male</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="gender" id="genderFemale" value="Female" required>
              <label class="form-check-label" for="genderFemale">Female</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="gender" id="genderOther" value="Other" required>
              <label class="form-check-label" for="genderOther">Other</label>
            </div>
          </div>

          <!-- Qualification Checkbox -->
          <div class="form-group">
            <label>Qualification:</label><br>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="qualification[]" id="qualificationHSC" value="HSC">
              <label class="form-check-label" for="qualificationHSC">HSC</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="qualification[]" id="qualificationUG" value="UG">
              <label class="form-check-label" for="qualificationUG">UG</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="qualification[]" id="qualificationPG" value="PG">
              <label class="form-check-label" for="qualificationPG">PG</label>
            </div>
          </div>

          <!-- Religion Dropdown -->
          <div class="form-group">
            <label for="religion">Religion:</label>
            <select class="form-control" id="religion" name="religion" required>
              <option >Select Religion</option>
              <option value="Hindu">Hindu</option>
              <option value="Muslim">Muslim</option>
              <option value="Christian">Christian</option>
            </select>
          </div>

          <!-- Image Input -->
          <div class="form-group">
            <label for="img">Profile Picture:</label>
            <input type="file" class="form-control-file" id="img" name="img" accept="image/*" required>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="save" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>
<!-- Buttons JS -->
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>

<script>
$(document).ready(function() {

    $.ajax({
        url: "ajax.php",
        type: "get",
        dataType: "json",
        data: {
            action: 'view'
        },
        success: function(res) {
            var rows = ""; // Initialize an empty string to hold all rows

            // Loop through the response data (the array of user information)
            for (let i = 0; i < res.length; i++) {
                // Build a new row for each entry in the response
                rows += `<tr>`;
                rows += `<td>${res[i][0]}</td>`; // User ID
                rows += `<td>${res[i][1]}</td>`; // Name
                rows += `<td>${res[i][2]}</td>`; // Email
                rows += `<td>${res[i][3]}</td>`; // Phone
                rows += `<td>${res[i][4]}</td>`; // Gender
                rows += `<td>${res[i][5]}</td>`; // Qualification
                rows += `<td>${res[i][6]}</td>`; // Religion
                rows += `<td><img src="${res[i][7]}" alt="Profile Image" width="50"></td>`; // Image
                rows += `<td> <button class="btn btn-success update btn-sm" data-id="${res[i][0]}">Update </button> <button class="btn btn-danger btn-sm deletee" data-id="${res[i][0]}">Delete </button> </td>`;
                rows += `</tr>`;
            }

            // Append all rows to the table body at once
            $("#tbody").append(rows);
            let table = new DataTable('#tablee', {
                responsive: true,
                dom: 'Bfltip', // Defines the position of the buttons
                    buttons: [
                        'copy', 'excel', 'print'
                    ]
            });
        },
        error: function(error, status, xhr) {
            console.error("AJAX Error: ", error);
        }
    });

    $(document).on('click','#save', function() { 
        
        var formData = new FormData($('#userForm')[0]); 
        formData.append('action', 'save');

        $.ajax({
            url: 'ajax.php', 
            type: 'POST',
            data: formData,
            contentType: false, 
            processData: false, 
            success: function(response) {
                var result = JSON.parse(response); 
                alert(result.msg); 
                if(result.status == "success") {
                    $('#exampleModal').modal('hide');
                    $('#userForm')[0].reset(); 
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: " + status + ": " + error);
            }
        });
    });
});
</script>
</body>
</html>