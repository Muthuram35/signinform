<?php 

$sname = "localhost";
$uname = "root";
$db    = "crud";
$pwd   = '';

$conn = mysqli_connect($sname, $uname, $pwd  , $db);

if(mysqli_connect_errno()){
    echo 'Connection Error'. mysqli_connect_error();
}

?>