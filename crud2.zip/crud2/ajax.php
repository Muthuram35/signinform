<?php 

include("./dbconfig.php ");

extract($_REQUEST);

if(isset($action)&&$action== "view"){


    $view = "SELECT * FROM users WHERE del is NULL";
    $res = mysqli_query($conn , $view) ;
    $row = mysqli_fetch_all($res);
    
    echo json_encode($row);

}

if(isset($action)&&$action== "save"){

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $religion = mysqli_real_escape_string($conn, $_POST['religion']);
    $qualification = implode(",", $_POST['qualification']);    

    $targerDir = "uploads/";
    $targetFile = $targerDir .basename($_FILES['img']['name']  ) ;
    $imgtype = strtolower(pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION));

    if(move_uploaded_file($_FILES['img']['tmp_name'],$targetFile)){

        $sql = "INSERT INTO users ( name , email , phone , gender , qualification , religion , img  ) VALUES ( '$name' , '$email','$phone','$gender','$qualification','$religion', '$targetFile' )";
        $res = mysqli_query($conn , $sql) ;

        if($res){
            echo json_encode(array("status"=> "success","msg"=> "saved successfully"));
        }else {
            echo json_encode(array("status" => "error", "msg" => "Database insert failed"));
        }
    }


}

if(isset($action)&&$action== "edit"){

    $edit = " SELECT * FROM users WHERE id = $id ";
    $res = mysqli_query($conn , $edit) ;
    $row = mysqli_fetch_all($res);

    echo json_encode($row);


}

if(isset($action)&&$action== "update"){

}

if(isset($action)&&$action== "delete"){

    $delete = "UPDATE users SET del = 1 WHERE id = $id";
    $res = mysqli_query($conn , $delete) ;

    if($res){
        echo json_encode(array("status"=> "success","msg"=> "deleted successfully"));
    }

}

?>