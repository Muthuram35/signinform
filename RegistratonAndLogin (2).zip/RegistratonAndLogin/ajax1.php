<?php 

require("dbconfig.php");
session_start();    
extract($_REQUEST);

if(isset($action) && $action == "signup") {

    $select = " SELECT * FROM register WHERE email = '$email' ";
    
    $res  = mysqli_query($conn, $select);

    $row = mysqli_fetch_array($res);

    if(mysqli_num_rows($res) == 0){ 

    $password = password_hash($password, PASSWORD_DEFAULT);    

    $sql = " INSERT INTO `register` ( name , email , password ) VALUES ( '$name','$email','$password' ) ";

    $result = mysqli_query($conn, $sql);

    if($result){
        $_SESSION["uname"] = $name;
        echo json_encode(["status"=> "success","msg"=> "Register Successfully"]);
    }

    }else{

        echo json_encode(["status"=> "error","msg"=> "email already exsist"]);
    }
}

// login check
if(isset($action) && $action == "login") {

    $select = " SELECT * FROM register WHERE email = '$email' LIMIT 1 ";

    $res = mysqli_query($conn , $select);

    if(mysqli_num_rows($res) > 0){

        $row = mysqli_fetch_array($res);

        $stored_password = $row['password'];

        if(password_verify($password,$stored_password)){

        $_SESSION["uname"] = $row["name"];

        echo json_encode(["status"=> "success","msg"=> "login Successfully"]);
        }else{
            echo json_encode(["status" => "error" , "msg" => "password not match" ]);
        }
    }else{
        echo json_encode(["status"=> "error","msg"=> "Please Check cridential"]);
    }

}

if(isset($action) && $action == "view") {
   
    $viewsql  = "SELECT * from register";
    $res = mysqli_query($conn, $viewsql);
    $row = mysqli_fetch_all($res);

    echo json_encode($row);
}

if( isset($action) && $action == "viewid") {

    $viewidsql  = " SELECT * FROM  register WHERE id = $id ";
    $res  = mysqli_query($conn,$viewidsql);
    $row  = mysqli_fetch_array( $res );

    echo json_encode($row);

}

if( isset($action) && $action == "delete") {


    $deletesql = " DELETE  FROM  register WHERE id = $id ";

    $res = mysqli_query($conn, $deletesql);

    if($res) {
        echo json_encode(["status"=> "success","msg"=> "Deleted Successfully"]);
    }

}

if (isset($action) && $action == "cookies") {

    $cookieExpirationTime = time() + 72000; 

    // Set the cookies (make sure they are HTTP only and secure if possible)
    setcookie("email", $email, $cookieExpirationTime, "/", "", false, true);  
    setcookie("password", $password, $cookieExpirationTime, "/", "", false, true); 


}

if( isset($action) && $action == "update") {


        $updatesql  = " UPDATE  register SET name = '$name' , email = '$email' , password = '$password'  where id = $id ";
        $res = mysqli_query($conn, $updatesql);

        if($res){
            echo json_encode(["status"=> "success","msg"=> "updated Successfully"]);
        }else{
            echo json_encode(["status"=> "success","msg"=> "updated failed"]);
        }


    
}

    if(isset($action) && $action == "sessionout") {
    // Destroy the session
    session_destroy();
    echo 'oh';
    
    header('Location: index.php');
    exit();
    }

?>